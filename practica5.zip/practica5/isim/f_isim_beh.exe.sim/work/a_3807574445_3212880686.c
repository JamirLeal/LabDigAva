/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/aldoj/Music/practica5/binToBCD.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2770553711_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_3143221075_1035706684(char *, char *, char *, int );


static void work_a_3807574445_3212880686_p_0(char *t0)
{
    char t13[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    unsigned char t12;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    int t30;

LAB0:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 1808U);
    t3 = *((char **)t1);
    t4 = (19 - 7);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t3 + t6);
    t7 = (t1 + 0);
    memcpy(t7, t2, 8U);
    t8 = (t0 + 1752U);
    xsi_variable_act(t8);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 5220);
    t3 = (t0 + 1808U);
    t7 = *((char **)t3);
    t4 = (19 - 11);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t3 = (t7 + t6);
    t8 = (t3 + 0);
    memcpy(t8, t1, 4U);
    t9 = (t0 + 1752U);
    xsi_variable_act(t9);
    xsi_set_current_line(61, ng0);
    t1 = (t0 + 5224);
    t3 = (t0 + 1808U);
    t7 = *((char **)t3);
    t4 = (19 - 15);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t3 = (t7 + t6);
    t8 = (t3 + 0);
    memcpy(t8, t1, 4U);
    t9 = (t0 + 1752U);
    xsi_variable_act(t9);
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 5228);
    t3 = (t0 + 1808U);
    t7 = *((char **)t3);
    t4 = (19 - 19);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t3 = (t7 + t6);
    t8 = (t3 + 0);
    memcpy(t8, t1, 4U);
    t9 = (t0 + 1752U);
    xsi_variable_act(t9);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 5232);
    *((int *)t1) = 1;
    t2 = (t0 + 5236);
    *((unsigned int *)t2) = 8U;
    t10 = 1;
    t11 = 8U;

LAB2:    if (t10 <= t11)
        goto LAB3;

LAB5:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t4 = (19 - 19);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 3192);
    t7 = (t3 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t14 = *((char **)t9);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t4 = (19 - 15);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 3256);
    t7 = (t3 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t14 = *((char **)t9);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t4 = (19 - 11);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 3320);
    t7 = (t3 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t14 = *((char **)t9);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    t1 = (t0 + 3112);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(66, ng0);
    t3 = (t0 + 1808U);
    t7 = *((char **)t3);
    t4 = (19 - 11);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t3 = (t7 + t6);
    t8 = (t0 + 5136U);
    t12 = ieee_p_1242562249_sub_3143221075_1035706684(IEEE_P_1242562249, t3, t8, 5);
    if (t12 != 0)
        goto LAB6;

LAB8:
LAB7:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t4 = (19 - 15);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 5152U);
    t12 = ieee_p_1242562249_sub_3143221075_1035706684(IEEE_P_1242562249, t1, t3, 5);
    if (t12 != 0)
        goto LAB9;

LAB11:
LAB10:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t4 = (19 - 19);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 5168U);
    t12 = ieee_p_1242562249_sub_3143221075_1035706684(IEEE_P_1242562249, t1, t3, 5);
    if (t12 != 0)
        goto LAB12;

LAB14:
LAB13:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 1808U);
    t2 = *((char **)t1);
    t1 = (t0 + 5104U);
    t3 = ieee_p_1242562249_sub_2770553711_1035706684(IEEE_P_1242562249, t13, t2, t1, 1);
    t7 = (t0 + 1808U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    t9 = (t13 + 12U);
    t4 = *((unsigned int *)t9);
    t4 = (t4 * 1U);
    memcpy(t7, t3, t4);

LAB4:    t1 = (t0 + 5232);
    t10 = *((int *)t1);
    t2 = (t0 + 5236);
    t11 = *((unsigned int *)t2);
    if (t10 == t11)
        goto LAB5;

LAB15:    t30 = (t10 + 1);
    t10 = t30;
    t3 = (t0 + 5232);
    *((int *)t3) = t10;
    goto LAB2;

LAB6:    xsi_set_current_line(67, ng0);
    t9 = (t0 + 1808U);
    t14 = *((char **)t9);
    t15 = (19 - 11);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t9 = (t14 + t17);
    t18 = (t0 + 5136U);
    t19 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t13, t9, t18, 3);
    t20 = (t0 + 1808U);
    t21 = *((char **)t20);
    t22 = (19 - 11);
    t23 = (t22 * 1U);
    t24 = (0 + t23);
    t20 = (t21 + t24);
    t25 = (t20 + 0);
    t26 = (t13 + 12U);
    t27 = *((unsigned int *)t26);
    t28 = (1U * t27);
    memcpy(t25, t19, t28);
    t29 = (t0 + 1752U);
    xsi_variable_act(t29);
    goto LAB7;

LAB9:    xsi_set_current_line(71, ng0);
    t7 = (t0 + 1808U);
    t8 = *((char **)t7);
    t15 = (19 - 15);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t7 = (t8 + t17);
    t9 = (t0 + 5152U);
    t14 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t13, t7, t9, 3);
    t18 = (t0 + 1808U);
    t19 = *((char **)t18);
    t22 = (19 - 15);
    t23 = (t22 * 1U);
    t24 = (0 + t23);
    t18 = (t19 + t24);
    t20 = (t18 + 0);
    t21 = (t13 + 12U);
    t27 = *((unsigned int *)t21);
    t28 = (1U * t27);
    memcpy(t20, t14, t28);
    t25 = (t0 + 1752U);
    xsi_variable_act(t25);
    goto LAB10;

LAB12:    xsi_set_current_line(75, ng0);
    t7 = (t0 + 1808U);
    t8 = *((char **)t7);
    t15 = (19 - 19);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t7 = (t8 + t17);
    t9 = (t0 + 5168U);
    t14 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t13, t7, t9, 3);
    t18 = (t0 + 1808U);
    t19 = *((char **)t18);
    t22 = (19 - 19);
    t23 = (t22 * 1U);
    t24 = (0 + t23);
    t18 = (t19 + t24);
    t20 = (t18 + 0);
    t21 = (t13 + 12U);
    t27 = *((unsigned int *)t21);
    t28 = (1U * t27);
    memcpy(t20, t14, t28);
    t25 = (t0 + 1752U);
    xsi_variable_act(t25);
    goto LAB13;

}


extern void work_a_3807574445_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3807574445_3212880686_p_0};
	xsi_register_didat("work_a_3807574445_3212880686", "isim/f_isim_beh.exe.sim/work/a_3807574445_3212880686.didat");
	xsi_register_executes(pe);
}
