/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/aldoj/Music/practica5/bcdTo7s.vhd";



static void work_a_0608663001_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned char t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned char t46;
    unsigned int t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t60;
    unsigned int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    unsigned char t74;
    unsigned int t75;
    char *t76;
    char *t77;
    char *t78;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    unsigned char t88;
    unsigned int t89;
    char *t90;
    char *t91;
    char *t92;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    unsigned char t102;
    unsigned int t103;
    char *t104;
    char *t105;
    char *t106;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    unsigned char t116;
    unsigned int t117;
    char *t118;
    char *t119;
    char *t120;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;
    char *t128;
    unsigned char t130;
    unsigned int t131;
    char *t132;
    char *t133;
    char *t134;
    char *t136;
    char *t137;
    char *t138;
    char *t139;
    char *t140;
    char *t141;
    char *t143;
    char *t144;
    char *t145;
    char *t146;
    char *t147;
    char *t148;

LAB0:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4280);
    t4 = 1;
    if (4U == 4U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB3;

LAB4:    t15 = (t0 + 1032U);
    t16 = *((char **)t15);
    t15 = (t0 + 4291);
    t18 = 1;
    if (4U == 4U)
        goto LAB13;

LAB14:    t18 = 0;

LAB15:    if (t18 != 0)
        goto LAB11;

LAB12:    t29 = (t0 + 1032U);
    t30 = *((char **)t29);
    t29 = (t0 + 4302);
    t32 = 1;
    if (4U == 4U)
        goto LAB21;

LAB22:    t32 = 0;

LAB23:    if (t32 != 0)
        goto LAB19;

LAB20:    t43 = (t0 + 1032U);
    t44 = *((char **)t43);
    t43 = (t0 + 4313);
    t46 = 1;
    if (4U == 4U)
        goto LAB29;

LAB30:    t46 = 0;

LAB31:    if (t46 != 0)
        goto LAB27;

LAB28:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t57 = (t0 + 4324);
    t60 = 1;
    if (4U == 4U)
        goto LAB37;

LAB38:    t60 = 0;

LAB39:    if (t60 != 0)
        goto LAB35;

LAB36:    t71 = (t0 + 1032U);
    t72 = *((char **)t71);
    t71 = (t0 + 4335);
    t74 = 1;
    if (4U == 4U)
        goto LAB45;

LAB46:    t74 = 0;

LAB47:    if (t74 != 0)
        goto LAB43;

LAB44:    t85 = (t0 + 1032U);
    t86 = *((char **)t85);
    t85 = (t0 + 4346);
    t88 = 1;
    if (4U == 4U)
        goto LAB53;

LAB54:    t88 = 0;

LAB55:    if (t88 != 0)
        goto LAB51;

LAB52:    t99 = (t0 + 1032U);
    t100 = *((char **)t99);
    t99 = (t0 + 4357);
    t102 = 1;
    if (4U == 4U)
        goto LAB61;

LAB62:    t102 = 0;

LAB63:    if (t102 != 0)
        goto LAB59;

LAB60:    t113 = (t0 + 1032U);
    t114 = *((char **)t113);
    t113 = (t0 + 4368);
    t116 = 1;
    if (4U == 4U)
        goto LAB69;

LAB70:    t116 = 0;

LAB71:    if (t116 != 0)
        goto LAB67;

LAB68:    t127 = (t0 + 1032U);
    t128 = *((char **)t127);
    t127 = (t0 + 4379);
    t130 = 1;
    if (4U == 4U)
        goto LAB77;

LAB78:    t130 = 0;

LAB79:    if (t130 != 0)
        goto LAB75;

LAB76:
LAB83:    t141 = (t0 + 4390);
    t143 = (t0 + 2752);
    t144 = (t143 + 56U);
    t145 = *((char **)t144);
    t146 = (t145 + 56U);
    t147 = *((char **)t146);
    memcpy(t147, t141, 7U);
    xsi_driver_first_trans_fast_port(t143);

LAB2:    t148 = (t0 + 2672);
    *((int *)t148) = 1;

LAB1:    return;
LAB3:    t8 = (t0 + 4284);
    t10 = (t0 + 2752);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t8, 7U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB2;

LAB5:    t5 = 0;

LAB8:    if (t5 < 4U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    t22 = (t0 + 4295);
    t24 = (t0 + 2752);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t22, 7U);
    xsi_driver_first_trans_fast_port(t24);
    goto LAB2;

LAB13:    t19 = 0;

LAB16:    if (t19 < 4U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t20 = (t16 + t19);
    t21 = (t15 + t19);
    if (*((unsigned char *)t20) != *((unsigned char *)t21))
        goto LAB14;

LAB18:    t19 = (t19 + 1);
    goto LAB16;

LAB19:    t36 = (t0 + 4306);
    t38 = (t0 + 2752);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 7U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB2;

LAB21:    t33 = 0;

LAB24:    if (t33 < 4U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t34 = (t30 + t33);
    t35 = (t29 + t33);
    if (*((unsigned char *)t34) != *((unsigned char *)t35))
        goto LAB22;

LAB26:    t33 = (t33 + 1);
    goto LAB24;

LAB27:    t50 = (t0 + 4317);
    t52 = (t0 + 2752);
    t53 = (t52 + 56U);
    t54 = *((char **)t53);
    t55 = (t54 + 56U);
    t56 = *((char **)t55);
    memcpy(t56, t50, 7U);
    xsi_driver_first_trans_fast_port(t52);
    goto LAB2;

LAB29:    t47 = 0;

LAB32:    if (t47 < 4U)
        goto LAB33;
    else
        goto LAB31;

LAB33:    t48 = (t44 + t47);
    t49 = (t43 + t47);
    if (*((unsigned char *)t48) != *((unsigned char *)t49))
        goto LAB30;

LAB34:    t47 = (t47 + 1);
    goto LAB32;

LAB35:    t64 = (t0 + 4328);
    t66 = (t0 + 2752);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    memcpy(t70, t64, 7U);
    xsi_driver_first_trans_fast_port(t66);
    goto LAB2;

LAB37:    t61 = 0;

LAB40:    if (t61 < 4U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t62 = (t58 + t61);
    t63 = (t57 + t61);
    if (*((unsigned char *)t62) != *((unsigned char *)t63))
        goto LAB38;

LAB42:    t61 = (t61 + 1);
    goto LAB40;

LAB43:    t78 = (t0 + 4339);
    t80 = (t0 + 2752);
    t81 = (t80 + 56U);
    t82 = *((char **)t81);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    memcpy(t84, t78, 7U);
    xsi_driver_first_trans_fast_port(t80);
    goto LAB2;

LAB45:    t75 = 0;

LAB48:    if (t75 < 4U)
        goto LAB49;
    else
        goto LAB47;

LAB49:    t76 = (t72 + t75);
    t77 = (t71 + t75);
    if (*((unsigned char *)t76) != *((unsigned char *)t77))
        goto LAB46;

LAB50:    t75 = (t75 + 1);
    goto LAB48;

LAB51:    t92 = (t0 + 4350);
    t94 = (t0 + 2752);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    t97 = (t96 + 56U);
    t98 = *((char **)t97);
    memcpy(t98, t92, 7U);
    xsi_driver_first_trans_fast_port(t94);
    goto LAB2;

LAB53:    t89 = 0;

LAB56:    if (t89 < 4U)
        goto LAB57;
    else
        goto LAB55;

LAB57:    t90 = (t86 + t89);
    t91 = (t85 + t89);
    if (*((unsigned char *)t90) != *((unsigned char *)t91))
        goto LAB54;

LAB58:    t89 = (t89 + 1);
    goto LAB56;

LAB59:    t106 = (t0 + 4361);
    t108 = (t0 + 2752);
    t109 = (t108 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    memcpy(t112, t106, 7U);
    xsi_driver_first_trans_fast_port(t108);
    goto LAB2;

LAB61:    t103 = 0;

LAB64:    if (t103 < 4U)
        goto LAB65;
    else
        goto LAB63;

LAB65:    t104 = (t100 + t103);
    t105 = (t99 + t103);
    if (*((unsigned char *)t104) != *((unsigned char *)t105))
        goto LAB62;

LAB66:    t103 = (t103 + 1);
    goto LAB64;

LAB67:    t120 = (t0 + 4372);
    t122 = (t0 + 2752);
    t123 = (t122 + 56U);
    t124 = *((char **)t123);
    t125 = (t124 + 56U);
    t126 = *((char **)t125);
    memcpy(t126, t120, 7U);
    xsi_driver_first_trans_fast_port(t122);
    goto LAB2;

LAB69:    t117 = 0;

LAB72:    if (t117 < 4U)
        goto LAB73;
    else
        goto LAB71;

LAB73:    t118 = (t114 + t117);
    t119 = (t113 + t117);
    if (*((unsigned char *)t118) != *((unsigned char *)t119))
        goto LAB70;

LAB74:    t117 = (t117 + 1);
    goto LAB72;

LAB75:    t134 = (t0 + 4383);
    t136 = (t0 + 2752);
    t137 = (t136 + 56U);
    t138 = *((char **)t137);
    t139 = (t138 + 56U);
    t140 = *((char **)t139);
    memcpy(t140, t134, 7U);
    xsi_driver_first_trans_fast_port(t136);
    goto LAB2;

LAB77:    t131 = 0;

LAB80:    if (t131 < 4U)
        goto LAB81;
    else
        goto LAB79;

LAB81:    t132 = (t128 + t131);
    t133 = (t127 + t131);
    if (*((unsigned char *)t132) != *((unsigned char *)t133))
        goto LAB78;

LAB82:    t131 = (t131 + 1);
    goto LAB80;

LAB84:    goto LAB2;

}


extern void work_a_0608663001_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0608663001_3212880686_p_0};
	xsi_register_didat("work_a_0608663001_3212880686", "isim/ff_isim_beh.exe.sim/work/a_0608663001_3212880686.didat");
	xsi_register_executes(pe);
}
